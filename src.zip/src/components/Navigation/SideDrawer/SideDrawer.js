import React from 'react';
import NavigationItem from '../NavigationItem/NavigationItem';
import Logo from '../../Logo/Logo';
import classes from './SideDrawer.css';
import Backdrop from '../../UI/Backdrop/Backdrop'
import Auxiliary from '../../../hoc/Auxiliary';

const sideDrawer = (props) => {
    let attachedClasses = [classes.SideDrawer, classes.Close];
    if (props.show) {
        attachedClasses = [classes.SideDrawer, classes.Open]
    }

    return (
        <Auxiliary>
            <Backdrop show={props.show} removeModal={props.removeModal} />
            <div className={attachedClasses.join(' ')}>
                <Logo height='11%' />
                <nav>
                    <NavigationItem isAuth={props.isAuth} />
                </nav>
            </div>
        </Auxiliary>
    )
};

export default sideDrawer;